var Constants =(function () {
    Constants.emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    Constants.numberRegex = /^[0-9]+$/;
    Constants.fullNameRegex = /^[a-zA-Z]{4,}(?: [a-zA-Z]+){0,2}$/;

    return Constants;
}());

exports.Constants = Constants;
